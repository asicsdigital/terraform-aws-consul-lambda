from __future__ import print_function
import json
import urllib2
import boto3
from botocore.exceptions import ClientError
from datetime import date
import consul

# inputs
# vpc_id
# ips = ['127.0.0.1', '127.0.0.2']

# No TTL or health checks on external services :(
#https://github.com/hashicorp/consul/issues/2089

'''
#### THIS IS THE GOOD BIT
c.catalog.register('db-prod', 'db-prod.ca4bhrmkhch7.us-east-1.rds.amazonaws.com', { "Service": "db-prod", "Port": 5432, "Tags": [ "rds" ]}, { "Status": "passing", "Name": "RDS" })
####
'''

def lambda_handler(event, context):
    # optionally add an array called vpc_ids which can be used to add resources from other VPC into a consul cluster
    #event = { "detail": { "consul_ips": ['127.0.0.1', '127.0.0.2'], "vpc_ids": ["vpc-d00dF4k3"] }}
    # = { "Code": { "Configuration": { "VpcConfig": { "VpcId": "vpc-d00dF4k3" }}}}

    def getConsulServers(vpc_id):
        consul_ips = []
        try:
            ec2 = boto3.client('ec2')
            response = ec2.describe_instances(Filters=[{'Name': 'tag:consul_server','Values': ['true',]},])
            for response in response['Reservations']:
                for instances in response['Instances']:
                    if instances['State']['Name'] == "running":
                        if instances['VpcId'] == vpc_id:
                            consul_ips.append(instances['PrivateIpAddress'])
            return consul_ips

        except RuntimeError as e:
            print(e.message)
        except ClientError as e:
            print(e.message)
        except Exception as e:
            print(e)
            raise e

    def getLambdaInfo(name):
        client = boto3.client('lambda')
        response = client.get_function(FunctionName=name)
        return response

    def getConsulConnection(ips):
        """Return a (Consul, ip_str) tuple if a Consul object can be created"""
        for host in ips:
            try:
                print ("trying : ", host)
                c = consul.Consul(host)
                try:
                    test = c.status.leader()
                    return (c)
                except Exception as e:
                    print(e)
                else:
                    print("failed to connect to {}".format(ip))
            except Exception as e:
                print(e)
        if not c:
          raise Exception("couldn't connect to any test IP")


    def getConsulRds():
        try:
            s = {}
            services = c.catalog.services()
            s = services[1]
            rds = []

            for k, v in s.iteritems():
                if 'rds' in v:
                    rds.append(k)
            return rds

        except RuntimeError as e:
            print(e.message)
        except ClientError as e:
            print(e.message)
        except Exception as e:
            print(e)
            raise e

    def registerRDS(db, Tags=[ "rds" ], is_aurora=False):
        #class Consul.Catalog.register(node, address, service=None, check=None, dc=None, token=None)

        def Register(
                DBInstanceIdentifier,
                ServiceName,
                DBEndpoint,
                DBPort,
                DBName,
                DBMasterUsername,
                Engine,
                EngineVersion,
                BackupRetentionPeriod,
                StorageEncrypted,
                MultiAZ,
                Tags):

            print("Processing: "+DBInstanceIdentifier)
            Engine                 = str(Engine)
            StorageEncrypted       = str(StorageEncrypted)
            BackupRetentionPeriod  = str(BackupRetentionPeriod)
            MultiAZ                = str(MultiAZ)

            Tags.append(Engine)
            c.catalog.register(DBInstanceIdentifier, (DBEndpoint), { "Service": ServiceName, "Port": DBPort, "Tags": Tags }, { "Status": "passing", "Name": "RDS" })
            Tags.remove(Engine)
            key = "aws/rds/"+DBInstanceIdentifier
            c.kv.put(key+"/DBName", DBName)
            c.kv.put(key+"/MasterUsername", DBMasterUsername)
            c.kv.put(key+"/Engine", Engine)
            c.kv.put(key+"/EngineVersion", EngineVersion)
            c.kv.put(key+"/StorageEncrypted", StorageEncrypted)
            c.kv.put(key+"/BackupRetentionPeriod", BackupRetentionPeriod)
            c.kv.put(key+"/MultiAZ", MultiAZ)

        if is_aurora:
            # Register WriterEndpoint
            print('Register Aurora Endpoint')
            Tags.append("rw")
            Register(
                db['DBClusterIdentifier'],
                db['DBClusterIdentifier'],
                db['Endpoint'],
                db['Port'],
                db['DatabaseName'],
                db['MasterUsername'],
                db['Engine'],
                db['EngineVersion'],
                db['BackupRetentionPeriod'],
                db['StorageEncrypted'],
                db['MultiAZ'],
                Tags)
            Tags.remove("rw")

            # Register ReaderEndpoint
            Tags.append("ro")
            Register(
                db['DBClusterIdentifier']+"-ro",
                db['DBClusterIdentifier']+"-ro",
                db['ReaderEndpoint'],
                db['Port'],
                db['DatabaseName'],
                db['MasterUsername'],
                db['Engine'],
                db['EngineVersion'],
                db['BackupRetentionPeriod'],
                db['StorageEncrypted'],
                db['MultiAZ'],
                Tags)
            Tags.remove("ro")

        else:
            Register(
                db['DBInstanceIdentifier'],
                db['DBInstanceIdentifier'],
                db['Endpoint']['Address'],
                db['Endpoint']['Port'],
                db['DBName'],
                db['MasterUsername'],
                db['Engine'],
                db['EngineVersion'],
                db['BackupRetentionPeriod'],
                db['StorageEncrypted'],
                db['MultiAZ'],
                Tags)

    def deregisterRDS(DBInstanceIdentifier):
        c.catalog.deregister(DBInstanceIdentifier)
        key = "aws/rds/"+DBInstanceIdentifier
        c.kv.delete(key, recurse=True)


    def filterRDSandAurora(response, vpc_id):
        rds_list = []
        aurora_list = []
        for db in response['DBInstances']:
            if db['DBSubnetGroup']['VpcId'] == vpc_id and db['DBInstanceStatus'] == "available":
                if db['Engine'] == 'aurora':
                    aurora_list.append(db)
                else:
                    rds_list.append(db)
        return(rds_list, aurora_list)

    def filterAuroraClusters(response):
        cluster_list = []
        for db in response:
            cluster = rds.describe_db_clusters(DBClusterIdentifier=db['DBClusterIdentifier'])
            #print(cluster['DBClusters'][0])
            cluster_list.append(cluster['DBClusters'][0])

        return(cluster_list)


    # Ok do some stuff
    lambda_info          = getLambdaInfo(context.function_name)
    vpc_id               = lambda_info['Configuration']['VpcConfig']['VpcId'] #my vpc id
    consul_ips           = getConsulServers(vpc_id)
    c                    = getConsulConnection(consul_ips)

    if 'vpc_ids' in event['detail'].keys():
        external_vpcs = event['detail']['vpc_ids']
        if vpc_id in external_vpcs:
            external_vpcs.remove(vpc_id)
        print('I Found an extra VPC')

    else:
        print('I have not found an extra VPC')
        external_vpcs = []


    try:
        rds = boto3.client('rds')
        rds_list = []
        aurora_endpoint_l = []
        consul_list = getConsulRds()
        response = rds.describe_db_instances()
        rds_instances, aurora_instances = filterRDSandAurora(response, vpc_id)
        aurora_clusters = filterAuroraClusters(aurora_instances)

        for db in rds_instances:
            registerRDS(db)
            rds_list.append(db['DBInstanceIdentifier'])

            if db['DBInstanceIdentifier'] in consul_list:
                consul_list.remove(db['DBInstanceIdentifier'])

        for cluster in aurora_clusters:
            if cluster['Endpoint'] not in aurora_endpoint_l:
                # Register the Endpoint
                aurora_endpoint_l.append(cluster['Endpoint'])
                rds_list.append(cluster['DBClusterIdentifier'])

                if cluster['DBClusterIdentifier'] in consul_list:
                    consul_list.remove(cluster['DBClusterIdentifier'])

            if cluster['ReaderEndpoint'] not in aurora_endpoint_l:
                aurora_endpoint_l.append(cluster['ReaderEndpoint'])
                ReaderDBClusterIdentifier = cluster['DBClusterIdentifier']+"-ro"
                rds_list.append(ReaderDBClusterIdentifier) # change to cluster['ReaderEndpoint'] - maybe?

                if ReaderDBClusterIdentifier in consul_list:
                    consul_list.remove(ReaderDBClusterIdentifier)
            # Now that housekeeping is done, register the aurora clusters in Consul
            registerRDS(cluster, is_aurora=True )


        if external_vpcs:
            for vpc in external_vpcs:
                rds_instances, aurora_instances = filterRDSandAurora(response, vpc)

                for db in rds_instances:
                    registerRDS(db)
                    rds_list.append(db['DBInstanceIdentifier'])

                    if db['DBInstanceIdentifier'] in consul_list:
                        consul_list.remove(db['DBInstanceIdentifier'])


                for cluster in aurora_clusters:
                    tags = [ "rds", "aurora" ]
                    if cluster['Endpoint'] not in aurora_endpoint_l:
                        # Register the Endpoint
                        aurora_endpoint_l.append(cluster['Endpoint'])
                        print("Register Aurora Endpoint: "+cluster['Endpoint'])
                        rds_list.append(cluster['DBClusterIdentifier'])

                        if cluster['DBClusterIdentifier'] in consul_list:
                            consul_list.remove(cluster['DBClusterIdentifier'])

                    if cluster['ReaderEndpoint'] not in aurora_endpoint_l:
                        aurora_endpoint_l.append(cluster['ReaderEndpoint'])
                        ReaderDBClusterIdentifier = cluster['DBClusterIdentifier']+"-ro"
                        print("Register Aurora ReaderEndpoint: "+cluster['ReaderEndpoint'])
                        rds_list.append(ReaderDBClusterIdentifier)

                        if ReaderDBClusterIdentifier in consul_list:
                            consul_list.remove(ReaderDBClusterIdentifier)

##
        for list in consul_list:
            print ("de-register "+list)
            deregisterRDS(list)

    except RuntimeError as e:
        print(e.message)
    except ClientError as e:
        print(e.message)
    except Exception as e:
        print(e)
        raise e
