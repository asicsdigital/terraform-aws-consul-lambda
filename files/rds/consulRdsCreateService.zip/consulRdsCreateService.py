from __future__ import print_function
import json
import urllib2
import boto3
from botocore.exceptions import ClientError
from datetime import date
import consul

# inputs
# vpc_id
# ips = ['127.0.0.1', '127.0.0.2']

# No TTL or health checks on external services :(
#https://github.com/hashicorp/consul/issues/2089

'''
#### THIS IS THE GOOD BIT
c.catalog.register('runkeeper-prod', 'runkeeper-prod.ca4bhrmkhch7.us-east-1.rds.amazonaws.com', { "Service": "runkeeper-prod", "Port": 5432, "Tags": [ "rds" ]}, { "Status": "passing", "Name": "RDS" })
####
'''

def lambda_handler(event, context):
    # optionally add an array called vpc_ids which can be used to add resources from other VPC into a consul cluster
    #event = { "detail": { "consul_ips": ['127.0.0.1', '127.0.0.2'], "vpc_ids": ["vpc-d0c675b4"] }}
    # = { "Code": { "Configuration": { "VpcConfig": { "VpcId": "vpc-d0c675b4" }}}}

    def getConsulServers(vpc_id):
        consul_ips = []
        try:
            ec2 = boto3.client('ec2')
            response = ec2.describe_instances(Filters=[{'Name': 'tag:consul_server','Values': ['true',]},])
            for response in response['Reservations']:
                for instances in response['Instances']:
                    if instances['VpcId'] == vpc_id:
                        consul_ips.append(instances['PrivateIpAddress'])
            return consul_ips

        except RuntimeError as e:
            print(e.message)
        except ClientError as e:
            print(e.message)
        except Exception as e:
            print(e)
            raise e

    def getLambdaInfo(name):
        client = boto3.client('lambda')
        response = client.get_function(FunctionName=name)
        return response

    def getConsulConnection(ips):
        """Return a (Consul, ip_str) tuple if a Consul object can be created"""
        for host in ips:
            try:
                print ("trying : ", host)
                c = consul.Consul(host)
                try:
                    test = c.status.leader()
                    return (c)
                except Exception as e:
                    print(e)
                else:
                    print("failed to connect to {}".format(ip))
            except Exception as e:
                print(e)
        if not c:
          raise Exception("couldn't connect to any test IP")


    def getConsulRds():
        try:
            s = {}
            services = c.catalog.services()
            s = services[1]
            rds = []

            for k, v in s.iteritems():
                if 'rds' in v:
                    rds.append(k)
            return rds

        except RuntimeError as e:
            print(e.message)
        except ClientError as e:
            print(e.message)
        except Exception as e:
            print(e)
            raise e

    def registerRDS(DBInstanceIdentifier, DBEndpoint, DBPort, DBName, DBMasterUsername ):
        c.catalog.register(DBInstanceIdentifier, (DBEndpoint), { "Service": DBInstanceIdentifier, "Port": DBPort, "Tags": [ "rds" ]}, { "Status": "passing", "Name": "RDS" })
        key = "aws/rds/"+DBInstanceIdentifier
        c.kv.put(key+"/DBName", DBName)
        c.kv.put(key+"/MasterUsername", DBMasterUsername)

    def deregisterRDS(DBInstanceIdentifier):
        c.catalog.deregister(DBInstanceIdentifier)
        key = "aws/rds/"+DBInstanceIdentifier
        c.kv.delete(key, recurse=True)

    # Ok do some stuff
    lambda_info          = getLambdaInfo(context.function_name)
    vpc_id               = lambda_info['Configuration']['VpcConfig']['VpcId'] #my vpc id
    consul_ips           = getConsulServers(vpc_id)
    c                    = getConsulConnection(consul_ips)

    if 'vpc_ids' in event['detail'].keys():
        external_vpcs = event['detail']['vpc_ids']
        if vpc_id in external_vpcs:
            external_vpcs.remove(vpc_id)
        print('I Found an extra VPC')

    else:
        print('I have not found an extra VPC')
        external_vpcs = []


    try:
        rds = boto3.client('rds')
        rds_list = []
        consul_list = getConsulRds()
        response = rds.describe_db_instances()

        for db in response['DBInstances']:
            if db['DBSubnetGroup']['VpcId'] == vpc_id and db['DBInstanceStatus'] == "available":
                registerRDS(db['DBInstanceIdentifier'], db['Endpoint']['Address'], db['Endpoint']['Port'], db['DBName'], db['MasterUsername'] )
                rds_list.append(db['DBInstanceIdentifier'])

                if db['DBInstanceIdentifier'] in consul_list:
                    consul_list.remove(db['DBInstanceIdentifier'])

            # This block makes me cry a bit
            if external_vpcs:
                for vpc in external_vpcs:
                    if db['DBSubnetGroup']['VpcId'] == vpc and db['DBInstanceStatus'] == "available":
                        registerRDS(db['DBInstanceIdentifier'], db['Endpoint']['Address'], db['Endpoint']['Port'], db['DBName'], db['MasterUsername'] )
                        rds_list.append(db['DBInstanceIdentifier'])
                        if db['DBInstanceIdentifier'] in consul_list:
                            consul_list.remove(db['DBInstanceIdentifier'])

        if consul_list:
            for list in consul_list:
                print ("de-register "+list)
                deregisterRDS(list)

    except RuntimeError as e:
        print(e.message)
    except ClientError as e:
        print(e.message)
    except Exception as e:
        print(e)
        raise e
